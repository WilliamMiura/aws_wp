<?php

$config = [
	'name' => __('Socials', 'blocksy'),
	'clone' => true,
	'selective_refresh' => [
		'footer_socials',
		'footerSocialsColor'
	],
];

